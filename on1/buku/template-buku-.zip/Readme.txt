Terdapat lima file latex yakni

1. main.tex (edit meta data)
2. Paper.tex (edit paper)
3. Pengesahan.tex (tidak perlu diedit)
4. Pernyataan.tex (tidak perlu diedit)
5. Cover.tex  (tidak perlu diedit)

Hanya dua file yang perlu diedit untuk mengkompilasi file pdf.

main.tex

    Merupakan file utama yang berisikan meta data. Mohon update meta data seperti nama, nim, pembimbing dll.

Paper.tex

    Merupakan file untuk mengisi hasil tugas akhir berupa paper.


FILE YANG TIDAK PERLU DIEDIT

Pengesahan.tex
Pernyataan.tex
Cover.tex